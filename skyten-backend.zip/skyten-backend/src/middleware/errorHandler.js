// Centralized error handler. Any `next(err)` call in the app lands here.
// Keep this as the LAST middleware registered in app.js.

function errorHandler(err, req, res, next) {
  console.error("[ERROR]", err.stack || err.message);

  // Prisma "record not found" style errors
  if (err.code === "P2025") {
    return res.status(404).json({ error: "Record not found." });
  }

  // Prisma unique constraint violation (e.g. duplicate email)
  if (err.code === "P2002") {
    return res.status(409).json({ error: `Duplicate value for field: ${err.meta?.target}` });
  }

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    error: err.message || "Something went wrong on the server.",
  });
}

// 404 handler for unmatched routes - registered right before errorHandler
function notFound(req, res, next) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

module.exports = { errorHandler, notFound };
