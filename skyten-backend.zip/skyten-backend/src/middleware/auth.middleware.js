const jwt = require("jsonwebtoken");

/**
 * verifyToken
 * Reads "Authorization: Bearer <token>" header, verifies it with JWT_SECRET,
 * and attaches the decoded payload (id, role) to req.user.
 */
function verifyToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "No token provided. Format: 'Bearer <token>'" });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // e.g. { id, role, iat, exp }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token." });
  }
}

/**
 * requireRole
 * Usage: requireRole("ADMIN") or requireRole("ADMIN", "TEAM_MEMBER")
 * Must be used AFTER verifyToken, since it reads req.user.role.
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated." });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: "You do not have permission to perform this action." });
    }
    next();
  };
}

module.exports = { verifyToken, requireRole };
