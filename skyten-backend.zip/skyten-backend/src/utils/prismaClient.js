// Single shared Prisma Client instance.
// Prevents "too many connections" errors that happen when every
// controller creates its own `new PrismaClient()`.

const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

module.exports = prisma;
