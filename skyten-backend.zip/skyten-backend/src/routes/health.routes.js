const express = require("express");
const router = express.Router();
const prisma = require("../utils/prismaClient");

// GET /api/health - quick check that the server and DB connection work
router.get("/", async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: "ok", database: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", database: "unreachable", details: err.message });
  }
});

module.exports = router;
